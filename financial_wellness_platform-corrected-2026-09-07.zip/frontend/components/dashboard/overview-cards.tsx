import { Transaction } from "../../types/transaction";
import { formatCurrency } from "../../lib/utils";
import { Card } from "../ui/card";

type OverviewCardsProps = {
  transactions: Transaction[];
  isLoading?: boolean;
};

export function OverviewCards({ transactions, isLoading }: OverviewCardsProps) {
  const totals = transactions.reduce(
    (accumulator, transaction) => {
      if (transaction.type === "income") {
        accumulator.income += transaction.amount;
      } else if (transaction.type === "expense") {
        accumulator.expenses += transaction.amount;
      } else {
        accumulator.emis += transaction.amount;
      }
      return accumulator;
    },
    { income: 0, expenses: 0, emis: 0 },
  );

  const savings = totals.income - totals.expenses - totals.emis;

  const cards = [
    { title: "Monthly Income", value: totals.income },
    { title: "Expenses", value: totals.expenses },
    { title: "EMIs", value: totals.emis },
    { title: "Net Savings", value: savings },
  ];

  return (
    <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
      {cards.map((card) => (
        <Card key={card.title}>
          <p className="text-sm text-slate-600">{card.title}</p>
          <p className="mt-2 text-2xl font-bold">
            {isLoading ? "..." : formatCurrency(card.value)}
          </p>
        </Card>
      ))}
    </section>
  );
}
