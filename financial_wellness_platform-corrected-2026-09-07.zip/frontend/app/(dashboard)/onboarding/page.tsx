"use client";

import { useEffect, useMemo, useState } from "react";
import { Card } from "../../../components/ui/card";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { useAuth } from "../../../hooks/useAuth";
import { api } from "../../../lib/api";
import {
  createFirstActionPlan,
  defaultOnboardingProfile,
  ONBOARDING_STORAGE_KEY,
  OnboardingProfile,
} from "../../../lib/onboarding";

function toNumber(value: string) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : 0;
}

export default function OnboardingPage() {
  const { user, loadProfile } = useAuth();
  const [form, setForm] = useState<OnboardingProfile>({
    ...defaultOnboardingProfile,
    monthlyIncome: user?.monthlyIncome ?? defaultOnboardingProfile.monthlyIncome,
  });
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const plan = useMemo(() => createFirstActionPlan(form), [form]);

  useEffect(() => {
    if ((form.monthlyIncome || 0) <= 0 && (user?.monthlyIncome || 0) > 0) {
      setForm((prev) => ({ ...prev, monthlyIncome: user.monthlyIncome }));
    }
  }, [form.monthlyIncome, user?.monthlyIncome]);

  const onSave = async () => {
    try {
      setError(null);
      setMessage(null);
      setIsSaving(true);

      localStorage.setItem(ONBOARDING_STORAGE_KEY, JSON.stringify(form));
      window.dispatchEvent(new Event("onboarding:updated"));

      await api.updateProfile({
        monthlyIncome: form.monthlyIncome,
      });
      await loadProfile();
      window.dispatchEvent(new Event("finance:updated"));

      setMessage("Onboarding saved. Your first action plan is now active on Dashboard.");
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Unable to save onboarding.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Onboarding</h1>
        <p className="text-sm text-slate-600">
          Complete this once to get your personalized first action plan.
        </p>
      </div>

      <Card>
        <h2 className="text-lg font-semibold">Step 1: Income, EMI, Expenses</h2>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <Input
            type="number"
            label="Monthly Income (INR)"
            value={String(form.monthlyIncome)}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, monthlyIncome: toNumber(event.target.value) }))
            }
          />
          <Input
            type="number"
            label="Monthly EMI (INR)"
            value={String(form.monthlyEmi)}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, monthlyEmi: toNumber(event.target.value) }))
            }
          />
          <Input
            type="number"
            label="Monthly Essentials (INR)"
            value={String(form.monthlyEssentials)}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, monthlyEssentials: toNumber(event.target.value) }))
            }
          />
          <Input
            type="number"
            label="Monthly Lifestyle Spend (INR)"
            value={String(form.monthlyLifestyle)}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, monthlyLifestyle: toNumber(event.target.value) }))
            }
          />
        </div>
      </Card>

      <Card>
        <h2 className="text-lg font-semibold">Step 2: Goal Planner</h2>
        <div className="mt-4 grid gap-3 md:grid-cols-2">
          <Input
            type="number"
            label="Current Savings (INR)"
            value={String(form.currentSavings)}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, currentSavings: toNumber(event.target.value) }))
            }
          />
          <Input
            label="Goal Name"
            value={form.goalName}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, goalName: event.target.value }))
            }
          />
          <Input
            type="number"
            label="Goal Target Amount (INR)"
            value={String(form.goalTargetAmount)}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, goalTargetAmount: toNumber(event.target.value) }))
            }
          />
          <Input
            type="number"
            label="Goal Timeline (Years)"
            value={String(form.goalYears)}
            onChange={(event) =>
              setForm((prev) => ({ ...prev, goalYears: toNumber(event.target.value) }))
            }
          />
        </div>
      </Card>

      <Card>
        <h2 className="text-lg font-semibold">Your First Action Plan Preview</h2>
        <div className="mt-3 grid gap-2 text-sm text-slate-700 md:grid-cols-2">
          <p>Suggested monthly cut: INR {plan.potentialCut.toLocaleString("en-IN")}</p>
          <p>Total SIP: INR {plan.suggestedSip.toLocaleString("en-IN")}</p>
          <p>Growth SIP (MF/Index): INR {plan.growthSip.toLocaleString("en-IN")}</p>
          <p>Emergency SIP (Liquid): INR {plan.emergencySip.toLocaleString("en-IN")}</p>
          <p>EMI Ratio: {(plan.emiRatio * 100).toFixed(1)}%</p>
          <p>Expense Ratio: {(plan.expenseRatio * 100).toFixed(1)}%</p>
        </div>
        <div className="mt-3 space-y-1 text-sm text-slate-700">
          {plan.recommendations.slice(0, 3).map((item) => (
            <p key={item}>- {item}</p>
          ))}
        </div>
      </Card>

      <div className="flex items-center gap-3">
        <Button onClick={onSave} isLoading={isSaving}>
          Save Onboarding
        </Button>
        {message ? <p className="text-sm text-green-700">{message}</p> : null}
        {error ? <p className="text-sm text-red-600">{error}</p> : null}
      </div>
    </div>
  );
}
